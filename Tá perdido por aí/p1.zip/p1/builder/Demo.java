package p1.builder;

import p1.builder.carros.Carro;
import p1.builder.carros.Manual;
import p1.builder.diretor.Diretor;

public class Demo {

    public static void main(String[] args) {
        Diretor diretor = new Diretor();

        CarroBuilder builder = new CarroBuilder();
        diretor.construirCarroEsportivo(builder);

        Carro carro = builder.getResult();
        System.out.println("Carro construido:\n" + carro.getTipoDeCarro());

        ManualDeCarroBuilder manualBuilder = new ManualDeCarroBuilder();

        diretor.construirCarroEsportivo(manualBuilder);
        Manual manualDeCarro = manualBuilder.getResult();
        System.out.println("\nManual de carro construido:\n" + manualDeCarro.print());
    }

}
