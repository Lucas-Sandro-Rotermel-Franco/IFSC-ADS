package p1.builder.diretor;

import p1.builder.Builder;
import p1.builder.carros.TipoDeCarro;
import p1.builder.componentes.ComputadorDeBordo;
import p1.builder.componentes.Motor;
import p1.builder.componentes.NavegadorGPS;
import p1.builder.componentes.Transmissao;

public class Diretor {

    public void construirCarroEsportivo(Builder builder) {
        builder.configurarTipoDeCarro(TipoDeCarro.CARRO_ESPORTIVO);
        builder.configurarAssentos(2);
        builder.configurarMotor(new Motor(3.0, 0));
        builder.configurarTransmissao(Transmissao.SEMI_AUTOMATICO);
        builder.configurarComputadorDeBordo(new ComputadorDeBordo());
        builder.configurarNavegadorGPS(new NavegadorGPS());
    }

    public void construirCarroUrbano(Builder builder) {
        builder.configurarTipoDeCarro(TipoDeCarro.CARRO_URBANO);
        builder.configurarAssentos(2);
        builder.configurarMotor(new Motor(1.2, 0));
        builder.configurarTransmissao(Transmissao.AUTOMATICO);
        builder.configurarComputadorDeBordo(new ComputadorDeBordo());
        builder.configurarNavegadorGPS(new NavegadorGPS());
    }

    public void construirSUV(Builder builder) {
        builder.configurarTipoDeCarro(TipoDeCarro.SUV);
        builder.configurarAssentos(4);
        builder.configurarMotor(new Motor(2.5, 0));
        builder.configurarTransmissao(Transmissao.MANUAL);
        builder.configurarNavegadorGPS(new NavegadorGPS());
    }
}
