package p1.builder.componentes;

import p1.builder.carros.Carro;

public class ComputadorDeBordo {

    private Carro carro;

    public void setCarro(Carro carro) {
        this.carro = carro;
    }

    public void mostrarNivelDeCombustivel() {
        System.out.println("Nivel de combustivel: " + carro.getCombustivel());
    }

    public void mostrarStatus() {
        if (this.carro.getMotor().estaLigado()) {
            System.out.println("Carro esta ligado");
        } else {
            System.out.println("Carro nao esta ligado");
        }
    }
}
