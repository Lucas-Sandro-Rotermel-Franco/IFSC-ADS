package p1.builder.componentes;

public enum Transmissao {
    VELOCIDADE_UNICA, MANUAL, AUTOMATICO, SEMI_AUTOMATICO
}