package p1.builder.componentes;

public class NavegadorGPS {
    private String rota;

    public NavegadorGPS() {
        this.rota = "R. Adriano Kormann, 510 - Bela Vista, Gaspar - SC";
    }

    public NavegadorGPS(String rotaManual) {
        this.rota = rotaManual;
    }

    public String getRota() {
        return rota;
    }
}