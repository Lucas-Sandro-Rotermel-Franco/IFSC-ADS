package p1.builder.carros;

public enum TipoDeCarro {
    CARRO_URBANO, CARRO_ESPORTIVO, SUV
}
