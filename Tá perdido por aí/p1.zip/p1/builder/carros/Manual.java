package p1.builder.carros;

import p1.builder.componentes.ComputadorDeBordo;
import p1.builder.componentes.Motor;
import p1.builder.componentes.NavegadorGPS;
import p1.builder.componentes.Transmissao;

public class Manual {
    private final TipoDeCarro tipoDeCarro;
    private final int assentos;
    private final Motor motor;
    private final Transmissao transmissao;
    private final ComputadorDeBordo computadorDeBordo;
    private final NavegadorGPS navegadorGPS;

    public Manual(TipoDeCarro tipoDeCarro, int assentos, Motor motor, Transmissao transmissao,
                  ComputadorDeBordo computadorDeBordo, NavegadorGPS navegadorGPS) {
        this.tipoDeCarro = tipoDeCarro;
        this.assentos = assentos;
        this.motor = motor;
        this.transmissao = transmissao;
        this.computadorDeBordo = computadorDeBordo;
        this.navegadorGPS = navegadorGPS;
    }

    public String print() {
        String info = "";
        info += "Tipo de carro: " + tipoDeCarro + "\n";
        info += "Contagem de assentos: " + assentos + "\n";
        info += "Motor: volume - " + motor.getVolume() + "; mileage - " + motor.getKilometragem() + "\n";
        info += "Transmissao: " + transmissao + "\n";
        if (this.computadorDeBordo != null) {
            info += "Computador de bordo: Funcional" + "\n";
        } else {
            info += "Computador de bordo: N/A" + "\n";
        }
        if (this.navegadorGPS != null) {
            info += "Navegador GPS: Funcional" + "\n";
        } else {
            info += "Navegador GPS: N/A" + "\n";
        }
        return info;
    }
}