package structurals.adapter;

public class TextShape extends TextView implements Shape{

	@Override
	public void BoundingBox(Point bottomLeft, Point topRight) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Manipulator CreateManipulator() {
		// TODO Auto-generated method stub
		return null;
	}

}
