package structurals.adapter;

public class Point {

}
