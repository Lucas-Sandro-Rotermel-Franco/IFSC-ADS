package Default;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

public class Empacotador implements Runnable
{
	private Buffer bufferRampa;
	private int qtdItensCarrinho;
	
	int cont = 0;
	Produto produto;

	public Empacotador(Buffer shared, int qtdItens)
	{
		bufferRampa = shared;
		qtdItensCarrinho = qtdItens;
	}

	@Override
	public void run()
	{
		do
		{
			produto = bufferRampa.get();
			cont++;
		}
		while (cont != qtdItensCarrinho);
				
		System.out.printf("Enpacolador: [" + getHora() + "] Fim do enpacolamento\n");
	}
	
	public String getHora()
	{
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		Date hora = Calendar.getInstance().getTime();
		String dataFormatada = sdf.format(hora);
		return dataFormatada;
	}
}