package Default;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

public class Consumidor implements Runnable
{
	private static Random generator = new Random();
	private Buffer sharedLocation;
	private Produto produto = new Produto();
	
	ArrayList<Produto> listaDeCompras = new ArrayList<Produto>();
	ArrayList<Produto> carrinhoCompras = new ArrayList<Produto>();
	
	private int qtdProdutos;

	public Consumidor(Buffer shared, int qtdProdutos)
	{
		sharedLocation = shared;
		this.qtdProdutos = qtdProdutos;
	}
	
	public int getQtdLista()
	{
		return listaDeCompras.size();
	}
	
	public void geraCarrinho()
	{
		produto.geraListaDeProdutos();

		Random random = new Random();
		
		for (int i = 0; i < qtdProdutos; i++)
			listaDeCompras.add(produto.getItem(random.nextInt(10)));
	}

	@Override
	public void run()
	{
		System.out.printf("Comprador: [" + getHora() + "] Iniciando compras.\n");
		geraCarrinho();
		for (Produto prod : listaDeCompras)
		{
			try
			{
				Thread.sleep(generator.nextInt((2000 - 1000) + 1) + 1000);
				
				carrinhoCompras.add(prod);
				System.out.printf("Comprador: [" + getHora() + "] Colocando " + prod.getNome() + " no carrinho.\n");
				
			} 
			catch (InterruptedException ex)
			{
				ex.printStackTrace();
			}
		}

		System.out.printf("Comprador: [" + getHora() + "] Indo para o caixa.\n");

		for (Produto produto : carrinhoCompras)
		{
			try
			{
				Thread.sleep(1000);
				System.out.printf("Comprador: [" + getHora() + "] Colocando " + produto.getNome() + " na esteira.\n");
				sharedLocation.set(produto);
			}
			catch (Exception ex)
			{
				ex.printStackTrace();
			}
		}

		System.out.printf("Carrinho vazio.\n");
	}

	public String getHora()
	{
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		Date hora = Calendar.getInstance().getTime();
		String dataFormatada = sdf.format(hora);
		return dataFormatada;
	}
}