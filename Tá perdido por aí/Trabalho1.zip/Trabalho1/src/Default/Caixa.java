package Default;

public class Caixa implements Runnable
{
	private Buffer sharedLocation;
	private Buffer bufferRampa;
	private int qtdItensCarrinho;

	public Caixa(Buffer esteiraBuffer, Buffer rampaBuffer, int qtdItemCompra)
	{
		sharedLocation = esteiraBuffer;
		bufferRampa = rampaBuffer;
		qtdItensCarrinho = qtdItemCompra;
	}

	@Override
	public void run()
	{
		for (int i = 0; i < qtdItensCarrinho; i++)
		{
			try
			{
				Thread.sleep(1000);
				bufferRampa.set(sharedLocation.get());
			}
			catch (InterruptedException exception)
			{
				exception.printStackTrace();
			}
		}
	}
}