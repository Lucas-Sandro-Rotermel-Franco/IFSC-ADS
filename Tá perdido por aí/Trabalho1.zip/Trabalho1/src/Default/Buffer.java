package Default;

public interface Buffer
{
	public Produto get();
	public void set(Produto prod);
}