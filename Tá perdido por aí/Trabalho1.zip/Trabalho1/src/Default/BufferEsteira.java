package Default;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class BufferEsteira implements Buffer
{
	private Produto buffer[];
	private int elementosInseridos = 0;
	private int posicaoLeitura = 0;
	private int posicaoEscrita = 0;

	public BufferEsteira(int capcidade)
	{
		super();
		buffer = new Produto[capcidade];
	}

	public synchronized void set(Produto produto)
	{
		try
		{
			while (elementosInseridos == buffer.length)
				wait();

			buffer[posicaoEscrita] = produto;
			posicaoEscrita = (posicaoEscrita + 1) % buffer.length;
			elementosInseridos++;
			notifyAll();
		}
		catch (InterruptedException e)
		{
			e.printStackTrace();
		}
	}

	public synchronized Produto get()
	{
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		Date hora = Calendar.getInstance().getTime();
		String dataFormatada = sdf.format(hora);
		Produto valor = null;
		
		try
		{
			while (elementosInseridos == 0)
				wait();
			
			valor = buffer[posicaoLeitura];
			posicaoLeitura = (posicaoLeitura + 1) % buffer.length;
			elementosInseridos--;
			
			Thread.sleep(2000);
			System.out.printf("Enpacolador: [" + dataFormatada + "] Acomodando " + valor.getNome() + " na sacola.\n");
			
			notifyAll();
		}
		catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		
		return valor;
	}
}