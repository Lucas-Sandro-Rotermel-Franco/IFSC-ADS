package Default;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

public class SharedBuffer
{
	public static void main(String[] args) throws InterruptedException
	{
		Random random = new Random();
		int qtdProduto = random.nextInt((30 - 10) + 1) + 10;
		
		Buffer sharedLocation = new BufferCircular(qtdProduto);
		Buffer bufferRampa = new BufferEsteira(qtdProduto);

		try
		{
			Thread consumidor = new Thread(new Consumidor(sharedLocation, qtdProduto));
			Thread caixa = new Thread(new Caixa(sharedLocation, bufferRampa, qtdProduto));
			Thread empacotador = new Thread(new Empacotador(bufferRampa, qtdProduto));
			
			consumidor.start();
			caixa.start();
			empacotador.start();
			
			consumidor.join();
			caixa.join();
			empacotador.join();
		}
		catch (Exception exception)
		{
			exception.printStackTrace();
		}
		
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		Date hora = Calendar.getInstance().getTime();
		String dataFormatada = sdf.format(hora);
		
		System.out.println("Fim da simulacao: [" + dataFormatada + "] :p");
	}
}