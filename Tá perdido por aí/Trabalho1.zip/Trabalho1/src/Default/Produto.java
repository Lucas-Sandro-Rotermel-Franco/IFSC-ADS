package Default;

import java.util.ArrayList;

public class Produto
{
	private String Nome;
	private double Preco;
	ArrayList<Produto> ListaDeProdutos = new ArrayList<Produto>();

	public Produto()
	{
	}

	public Produto(String nome, double preco)
	{
		super();
		this.Nome = nome;
		this.Preco = preco;
	}

	public void geraListaDeProdutos()
	{
		ListaDeProdutos.add(new Produto("Biscoito", 2.00));
		ListaDeProdutos.add(new Produto("Bolacha>Biscoito", 1.50));
		ListaDeProdutos.add(new Produto("Frango", 10.00));
		ListaDeProdutos.add(new Produto("Batata", 2.00));
		ListaDeProdutos.add(new Produto("Vodka", 15.00));
		ListaDeProdutos.add(new Produto("Alface", 0.50));
		ListaDeProdutos.add(new Produto("Arroz", 10.00));
		ListaDeProdutos.add(new Produto("Feijao", 10.00));
		ListaDeProdutos.add(new Produto("Ouro Branco", 1.50));
		ListaDeProdutos.add(new Produto("Energetico", 12.00));
	}
	
	public Produto getItem(int i)
	{
		return ListaDeProdutos.get(i);
	}
	
	public String getNome()
	{
		return Nome;
	}

	public void setNome(String descricao)
	{
		this.Nome = descricao;
	}

	public double getPreco()
	{
		return Preco;
	}

	public void setPreco(float preco)
	{
		this.Preco = preco;
	}
}