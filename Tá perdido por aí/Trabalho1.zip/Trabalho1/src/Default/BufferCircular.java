package Default;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

public class BufferCircular implements Buffer
{
	private Produto buffer[];
	private int elementosInseridos = 0;
	private int posicaoLeitura = 0;
	private int posicaoEscrita = 0;
	private double valorCompra = 0;
	private int cont = 1;
	private int qtdItens = 0;
	public BufferCircular(int capacidade)
	{
		super();
		buffer = new Produto[capacidade];
		qtdItens = capacidade;
	}

	public synchronized void set(Produto produto)
	{
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		Date hora = Calendar.getInstance().getTime();
		String dataFormatada = sdf.format(hora);
		try
		{
			while (elementosInseridos == buffer.length)
				wait();
			
			buffer[posicaoEscrita] = produto;
			
			posicaoEscrita = (posicaoEscrita + 1) % buffer.length;
			elementosInseridos++;
			notifyAll();
		}
		catch (InterruptedException e)
		{
			e.printStackTrace();
		}
	}

	public synchronized Produto get()
	{
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		Date hora = Calendar.getInstance().getTime();
		String dataFormatada = sdf.format(hora);
		Produto valor = null;
		
		try
		{
			while (elementosInseridos == 0)
				wait();
			
			valor = buffer[posicaoLeitura];
			posicaoLeitura = (posicaoLeitura + 1) % buffer.length;
			elementosInseridos--;
			valorCompra += valor.getPreco();
			
			Thread.sleep(new Random().nextInt((4000 - 2000) + 1) + 2000);
			System.out.printf("Caixa: [" + dataFormatada + "] Passando " + valor.getNome() + " - " + valor.getPreco() + "\n");
			
			if (cont == qtdItens)
			{
				System.out.println("Caixa: [" + dataFormatada + "] Informando valor da compra: " + valorCompra + "\n");
				System.out.println("Comprador: [" + dataFormatada + "] Pagando a compra: " + valorCompra + "\n");
			}
			
			cont++;
			notifyAll();
		}
		catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		
		return valor;
	}
}