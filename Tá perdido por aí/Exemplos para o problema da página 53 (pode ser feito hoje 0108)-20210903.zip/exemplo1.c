#include <stdio.h>
#include <dirent.h>
#include <sys/stat.h>

int main()
{
    DIR *dir = opendir(".");
    struct dirent *dirent;
    struct stat stats;
    
    if (dir)
    {
        while ((dirent = readdir(dir)))
        {
            stat(dirent->d_name, &stats);
            
            if(S_ISDIR(stats.st_mode)){
				printf("Directory name: %s\n", dirent->d_name);
			} else  if(S_ISREG(stats.st_mode)) {
				printf("File name: %s\n", dirent->d_name);
			}		
        }
    }
    else
    {
        fprintf(stderr, "error: cannot access directory\n");
    }
    
    closedir(dir);
    
    return 0;
} 
