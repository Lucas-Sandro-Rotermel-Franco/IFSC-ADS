#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>


int main()
{

	char buffer[100];
	int readed;

	int file = open("saida.txt", O_CREAT | O_WRONLY | O_APPEND, S_IRWXU);
	
	if(file == -1){
	    perror("Erro");
	}	
	
	while((readed = read(1, buffer, 100)) > 0){
		
		buffer[readed] = 0;
		
		if(readed == 1) break;
		
		write(file, buffer, readed);
		
	}	
	
	
	close(file);
	
	return 0;

} 

