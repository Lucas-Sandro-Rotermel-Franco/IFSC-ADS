#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>


int main()
{

	char buffer[100];

	int file = open("/proc/cpuinfo", O_RDONLY);
	
	while(read(file, buffer, 100) > 0){
		
		printf("%s", buffer);
		
	}
	
	close(file);	
	
	
	return 0;

} 

