
public class Aluno {

	String nome;
	int matricula;
	int telefone;
	String email;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getMatricula() {
		return matricula;
	}

	public void setMatricula(int matricula) {
		this.matricula = matricula;
	}

	public int getTelefone() {
		return telefone;
	}

	public void setTelefone(int telefone) {
		this.telefone = telefone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	
	public void nome() {
		System.out.println("Nome do aluno:" + this.nome);
	}
	
	public void matricula() {
		System.out.println("Matricula do aluno:" + this.matricula);
	}
	public void telefone() {
		System.out.println("Telfone do aluno:" + this.telefone);
	}
	public void email() {
		System.out.println("Email do aluno:" + this.email);
	}
}
