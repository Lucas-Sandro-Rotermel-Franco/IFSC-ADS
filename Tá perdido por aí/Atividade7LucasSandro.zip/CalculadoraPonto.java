
public class CalculadoraPonto implements Operacoes {

	@Override
	public Ponto adicao(Ponto ponto1, Ponto ponto2) {
		Ponto ponto = new Ponto();
		ponto.setX(ponto1.getX()+ponto2.getX());
		ponto.setY(ponto1.getY()+ponto2.getY());
		return ponto;
	}

	@Override
	public Ponto multiplicacao(int numero, Ponto ponto) {
		Ponto ponto1 = new Ponto();
		ponto1.setX(numero*ponto.getX());
		ponto1.setY(numero*ponto.getY());
		return ponto1;
	}

	@Override
	public double distancia(Ponto ponto1, Ponto ponto2) {
		
		return 3;
	}

	@Override
	public double norma(Ponto ponto) {
		// TODO Auto-generated method stub
		return 15;
	}

	@Override
	public boolean igual(Ponto ponto1, Ponto ponto2) {
		// TODO Auto-generated method stub
		return true;
	}

}
