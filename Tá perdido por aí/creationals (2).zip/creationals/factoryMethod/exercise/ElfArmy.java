package creationals.factoryMethod.exercise;
public class ElfArmy{
  public String getDescription() {
    return "This is the Elf Army!";
  }
}
