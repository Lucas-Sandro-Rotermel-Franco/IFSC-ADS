package creationals.factoryMethod.exercise;
public class OrcArmy {

  public String getDescription() {
    return "This is the Orc Army!";
  }
}
