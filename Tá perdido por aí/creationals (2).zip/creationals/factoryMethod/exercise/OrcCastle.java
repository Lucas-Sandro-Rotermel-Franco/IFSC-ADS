package creationals.factoryMethod.exercise;
public class OrcCastle {
	
  public String getDescription() {
    return "This is the Orc castle!";
  }
}
