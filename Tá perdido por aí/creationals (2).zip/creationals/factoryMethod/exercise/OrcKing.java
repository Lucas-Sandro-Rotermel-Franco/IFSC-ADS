package creationals.factoryMethod.exercise;
public class OrcKing{

  public String getDescription() {
    return "This is the Orc king!";
  }
}
