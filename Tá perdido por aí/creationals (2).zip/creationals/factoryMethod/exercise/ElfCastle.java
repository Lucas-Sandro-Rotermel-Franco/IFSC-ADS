package creationals.factoryMethod.exercise;
public class ElfCastle {

  public String getDescription() {
    return "This is the Elf castle!";
  }
}
