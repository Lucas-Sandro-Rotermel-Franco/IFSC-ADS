package creationals.factoryMethod.exercise;
public class ElfKing {

  public String getDescription() {
    return "This is the Elf king!";
  }
}
