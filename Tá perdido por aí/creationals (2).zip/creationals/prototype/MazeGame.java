package creationals.prototype;

public class MazeGame {

}
