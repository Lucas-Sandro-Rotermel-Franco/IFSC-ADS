package creationals.builder;

import creationals.maze.Maze;

public class StandardMazeBuilder implements MazeBuilder{

	@Override
	public void BuildMaze() {}

	@Override
	public void BuildRoom(int room) {}

	@Override
	public void BuilDoor(int roomFrom, int roomTo) {}

	@Override
	public Maze GetMaze() {
		// TODO
		return null;
	}
}
