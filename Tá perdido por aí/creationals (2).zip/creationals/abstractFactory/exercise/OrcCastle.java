package creationals.abstractFactory.exercise;
public class OrcCastle {
	
  public String getDescription() {
    return "This is the Orc castle!";
  }
}
