package creationals.abstractFactory.exercise;
public class OrcArmy {

  public String getDescription() {
    return "This is the Orc Army!";
  }
}
