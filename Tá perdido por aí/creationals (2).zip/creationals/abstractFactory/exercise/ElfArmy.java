package creationals.abstractFactory.exercise;
public class ElfArmy{
  public String getDescription() {
    return "This is the Elf Army!";
  }
}
