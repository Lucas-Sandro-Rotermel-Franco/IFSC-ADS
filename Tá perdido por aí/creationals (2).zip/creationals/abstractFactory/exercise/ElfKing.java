package creationals.abstractFactory.exercise;
public class ElfKing {

  public String getDescription() {
    return "This is the Elf king!";
  }
}
