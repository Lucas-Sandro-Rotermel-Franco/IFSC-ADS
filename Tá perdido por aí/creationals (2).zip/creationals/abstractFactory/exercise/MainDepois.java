package creationals.abstractFactory.exercise;

public class MainDepois {
	public static void main(String[] args) {
		Kingdom kingdom;
		
		kingdom = new ElfKingdom(new ElfKingdomFactory());
		kingdom.getDescription();
	
		kingdom = new OrcKingdom(new OrcKingdomFactory());
		kingdom.getDescription();
	}
}