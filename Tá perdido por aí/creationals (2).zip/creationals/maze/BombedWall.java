package creationals.maze;

import creationals.maze.Wall;

public class BombedWall extends Wall {

}
