package creationals.maze;

public class Wall implements MapSite {

	@Override
	public void Enter() {
		// TODO Auto-generated method stub

	}

	@Override
	public Wall Clone() {
		// TODO Auto-generated method stub
		return null;
	}

}
