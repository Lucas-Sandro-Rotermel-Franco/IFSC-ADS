package creationals.maze;

import creationals.maze.Room;

public class RoomWithABomb extends Room {

	// Empty, for prototype
	public RoomWithABomb() {
		super();
	}
	
	public RoomWithABomb(int _roomNumber) {
		super(_roomNumber);
	}

}
