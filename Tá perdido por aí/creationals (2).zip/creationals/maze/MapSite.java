package creationals.maze;

public interface MapSite {
 
	public void Enter();
	
	public MapSite Clone();
}
