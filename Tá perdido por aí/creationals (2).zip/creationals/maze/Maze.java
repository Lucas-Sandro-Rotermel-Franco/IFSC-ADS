package creationals.maze;

import java.util.ArrayList;

public class Maze {

	private ArrayList<MapSite> rooms = new ArrayList<MapSite>();
	
	public void AddRoom(Room room) {
		rooms.add(room);
	}
	
	public Room RoomNo(int roomNo) {
		// TODO
		return null;
	}
}
