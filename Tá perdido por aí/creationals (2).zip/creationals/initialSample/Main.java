package creationals.initialSample;

import creationals.maze.Maze;

public class Main {
	public static void main(String[] args) {
		MazeGame mGame = new MazeGame();
		
		Maze maze = mGame.CreateMaze();
	}
}
