
public class AlbumCollectionItemBuilder implements CollectionItemBuilder {
	private Album album;
	
	@Override
	public CollectionItemBuilder buildItem() {
		album = new Album();
		return this;
	}

	@Override
	public CollectionItemBuilder setName(String name) {
		album.setName(name);
		return this;
	}

	@Override
	public CollectionItemBuilder setYear(int year) {
		album.setYear(year);
		return this;
	}

	@Override
	public CollectionItemBuilder setPublisher(String publisher) {
		album.setRecordCompany(publisher);
		return this;
	}

	@Override
	public CollectionItemBuilder addAuthor(String author) {
		album.addAuthor(author);
		return this;
	}

	@Override
	public CollectionItemBuilder addContent(String content) {
		album.addAlbum(content);
		return this;
	}

	public Album getAlbum() {
		return album;
	}

}
