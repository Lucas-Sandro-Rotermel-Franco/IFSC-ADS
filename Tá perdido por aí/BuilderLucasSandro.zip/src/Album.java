import java.util.LinkedList;
import java.util.List;

public class Album {

	private String name;
	private String recordCompany;
	private int year;
	private List<String> authors;
	private List<String> tracks;
	
	public Album() {
		authors = new LinkedList<String>();
		tracks = new LinkedList<String>();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRecordCompany() {
		return recordCompany;
	}

	public void setRecordCompany(String recordCompany) {
		this.recordCompany = recordCompany;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public List<String> getAuthors() {
		return authors;
	}

	public void addAuthor(String author) {
		authors.add(author);
	}

	public List<String> getTracks() {
		return tracks;
	}

	public void addAlbum(String track) {
		tracks.add(track);
	}
	
	public void print() {
		System.out.println("Album");
		System.out.println("Name: " + getName());
		System.out.println("Record Company: " + getRecordCompany());
		System.out.println("Year: " + getYear());
		
		System.out.println("Author(s): ");
		for (String author : getAuthors())
			System.out.println("  - " + author);
		
		System.out.println("Track(s): ");
		for (String track : getTracks())
			System.out.println("  - " + track);
	}
	
}
