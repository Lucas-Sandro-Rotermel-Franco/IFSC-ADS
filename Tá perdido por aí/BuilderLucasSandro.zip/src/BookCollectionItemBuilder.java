
public class BookCollectionItemBuilder implements CollectionItemBuilder {
	private Book book;
	@Override
	public CollectionItemBuilder buildItem() {
		book = new Book();
		return this;
	}

	@Override
	public CollectionItemBuilder setName(String name) {
		book.setName(name);
		return this;
	}

	@Override
	public CollectionItemBuilder setYear(int year) {
		book.setYear(year);
		return this;
	}

	@Override
	public CollectionItemBuilder setPublisher(String publisher) {
		book.setPublishingCompany(publisher);
		return this;
	}

	@Override
	public CollectionItemBuilder addAuthor(String author) {
		book.addAuthor(author);
		return this;
	}

	@Override
	public CollectionItemBuilder addContent(String content) {
		book.addChapter(content);
		return this;
	}

	public Book getBook() {
		return book;
	}

}
