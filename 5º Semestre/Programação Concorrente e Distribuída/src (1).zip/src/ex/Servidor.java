package ex;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor {

	public static void main(String args[]) throws IOException {
		ServerSocket servidor = new ServerSocket(1234);
		Socket cliente = servidor.accept();

		DataInputStream dis = new DataInputStream(cliente.getInputStream());

		while (true) {
			if (dis.available() > 0) {
				String mensagem = dis.readUTF();
				System.out.println(new StringBuilder(mensagem).reverse().toString());
				break;
			}
		}
	}
}