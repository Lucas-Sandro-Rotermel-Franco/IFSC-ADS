package ex;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class Cliente {

	public static void main(String args[]) throws IOException {

		System.out.println("Digite uma mensagem:");
		Scanner teclado = new Scanner(System.in);
		Socket cliente = new Socket("localhost", 1234);

		DataOutputStream dos = new DataOutputStream(cliente.getOutputStream());
		dos.writeUTF(teclado.next());
		dos.flush();
		dos.close();
		cliente.close();
	}
}
