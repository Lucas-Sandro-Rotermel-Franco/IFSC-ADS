
 class MyThread1 extends Thread{

	@Override
	public void run() {
		System.out.println("Thread A iniciou");
		for (int idxA = 0; idxA < 5; idxA++) {
			System.out.println("\t Da ThreadA: idxA = " + idxA);
		}
		System.out.println("Termino de A");
		
	}

}
 
 class MyThread2 extends Thread{

	@Override
	public void run() {
		System.out.println("Thread B iniciou");
		for (int idxB = 0; idxB < 5; idxB++) {
			System.out.println("\t Da ThreadB: idxB = " + idxB);
		}
		System.out.println("Termino de B");
		
	}

}
 
 class MyThread3 extends Thread{

	@Override
	public void run() {
		System.out.println("Thread C iniciou");
		for (int idxC = 0; idxC < 5; idxC++) {
			System.out.println("\t Da ThreadC: idxC = " + idxC);
		}
		System.out.println("Termino de C");
		
	}

}

public class Main {

	public static void main(String[] args) {
		MyThread1 A = new MyThread1();
		MyThread2 B = new MyThread2();
		MyThread3 C = new MyThread3();
		
		A.setPriority(Thread.MIN_PRIORITY);
		B.setPriority(Thread.NORM_PRIORITY);
		C.setPriority(Thread.MAX_PRIORITY);
		
		A.start();
		B.start();
		C.start();
	}

}
