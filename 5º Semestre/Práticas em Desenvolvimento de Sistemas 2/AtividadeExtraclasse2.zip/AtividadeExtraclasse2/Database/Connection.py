import pymysql.cursors

def connection():
    conn = pymysql.connect(
        host="127.0.0.1",
        user="root",
        password="user",
        db="estoque",
        charset = 'utf8mb4',
        cursorclass = pymysql.cursors.DictCursor
    )
    
    return conn