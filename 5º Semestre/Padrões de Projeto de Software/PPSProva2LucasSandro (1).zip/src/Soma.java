
public class Soma extends Expressao {

	public Soma(Expressao exp1, Expressao exp2) {
		resultado = exp1.avaliar() + exp2.avaliar();
	}
}
