
public class Valor extends Expressao {

	public Valor(int i) {
		resultado = i;
	}

	public Valor(double d) {
		resultado = d;
	}
}
