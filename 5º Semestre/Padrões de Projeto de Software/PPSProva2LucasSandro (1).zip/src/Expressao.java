
public abstract class Expressao {
	protected double resultado;
	
	protected double avaliar() {
		return resultado;
	}

}
