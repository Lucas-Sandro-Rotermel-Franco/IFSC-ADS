
public class Multiplicacao extends Expressao {

	public Multiplicacao(Expressao exp1, Expressao exp2) {
		resultado = exp1.avaliar() * exp2.avaliar();
	}
}
