
public class Divisao extends Expressao {

	public Divisao(Expressao exp1, Expressao exp2) {
		resultado = exp1.avaliar() / exp2.avaliar();
	}
}
