public class Demo {
	public static void main(String[] args) {
		Expressao e = new Divisao(
						 new Multiplicacao(
								 new Valor(40),
								 new Valor(3)),
						 new Soma(
								 new Valor(2),
								 new Subtracao(
									new Valor(10),
									new Valor(6.0))));
		
		// Espressao (em valores reais): (40*3)/(2+(10-6)) = 120
		System.out.println("Resultado: " + e.avaliar());
	}
}