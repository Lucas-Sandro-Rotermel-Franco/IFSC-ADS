package structurals.bridge;

public class View {

}
