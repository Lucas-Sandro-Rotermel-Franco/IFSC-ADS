package structurals.adapter.exercise1;

public class Rectangle {
    public void drawRectangle(int x, int y, int width, int height) {
        System.out.println("Rectangle with coordinate left-down point (" + x + ";" + y + "), width: " + width
                + ", height: " + height);
    }
}
