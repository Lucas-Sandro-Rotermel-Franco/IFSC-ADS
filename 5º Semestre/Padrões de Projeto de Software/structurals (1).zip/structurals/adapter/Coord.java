package structurals.adapter;

public class Coord {

}
