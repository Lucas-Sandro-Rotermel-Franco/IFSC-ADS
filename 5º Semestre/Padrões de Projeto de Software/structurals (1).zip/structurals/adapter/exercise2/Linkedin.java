package structurals.adapter.exercise2;

public class Linkedin {
	public void submit(String msg) {
		System.out.println("Linkedin: " + msg);
		
	}
}
