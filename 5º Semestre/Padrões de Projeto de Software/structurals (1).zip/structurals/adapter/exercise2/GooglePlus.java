package structurals.adapter.exercise2;

public class GooglePlus {
	public void post(String msg) {
		System.out.println("GooglePlus: "+ msg);

	}

}
