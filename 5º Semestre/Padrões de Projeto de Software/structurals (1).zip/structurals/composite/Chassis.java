package structurals.composite;

public class Chassis extends CompositeEquipament{

	protected Chassis(String name) {
		super(name);
	}

}
