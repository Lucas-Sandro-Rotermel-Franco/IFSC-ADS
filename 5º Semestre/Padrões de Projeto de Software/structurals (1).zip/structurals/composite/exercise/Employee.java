package structurals.composite.exercise;

public interface Employee {
	public void showEmployeeDetails();
}
