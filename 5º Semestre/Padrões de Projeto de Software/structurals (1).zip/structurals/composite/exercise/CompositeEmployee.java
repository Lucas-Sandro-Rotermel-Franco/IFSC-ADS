package structurals.composite.exercise;

public class CompositeEmployee {

}
