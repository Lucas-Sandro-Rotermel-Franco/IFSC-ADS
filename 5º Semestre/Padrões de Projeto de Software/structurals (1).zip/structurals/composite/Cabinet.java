package structurals.composite;

public class Cabinet extends CompositeEquipament{

	protected Cabinet(String name) {
		super(name);
	}

}
