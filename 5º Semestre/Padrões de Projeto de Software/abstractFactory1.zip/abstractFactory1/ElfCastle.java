package abstractFactory1;
public class ElfCastle {

  public String getDescription() {
    return "This is the Elf castle!";
  }
}
