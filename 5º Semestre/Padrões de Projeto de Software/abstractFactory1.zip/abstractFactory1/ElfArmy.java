package abstractFactory1;
public class ElfArmy{
  public String getDescription() {
    return "This is the Elf Army!";
  }
}
