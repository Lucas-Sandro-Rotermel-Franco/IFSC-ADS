package abstractFactory1;
public class OrcCastle {
	
  public String getDescription() {
    return "This is the Orc castle!";
  }
}
