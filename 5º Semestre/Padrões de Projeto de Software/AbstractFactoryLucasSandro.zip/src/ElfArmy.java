public class ElfArmy implements Army{
  public String getDescription() {
    return "This is the Elf Army!";
  }
}
