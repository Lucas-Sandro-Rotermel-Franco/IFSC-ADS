public class OrcCastle implements Castle {
	
  public String getDescription() {
    return "This is the Orc castle!";
  }
}
