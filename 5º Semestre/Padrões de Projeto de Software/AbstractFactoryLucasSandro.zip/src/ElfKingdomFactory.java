
public class ElfKingdomFactory {
	public ElfCastle MakeElfCastle() {
		return new ElfCastle();
	}
	
	public ElfArmy MakeElfArmy() {
		return new ElfArmy();
	}
	
	public ElfKing MakeElfKing() {
		return new ElfKing();
	}
}
