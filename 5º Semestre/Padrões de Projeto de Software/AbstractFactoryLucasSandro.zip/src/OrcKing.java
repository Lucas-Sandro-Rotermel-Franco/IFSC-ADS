public class OrcKing implements King{

  public String getDescription() {
    return "This is the Orc king!";
  }
}
