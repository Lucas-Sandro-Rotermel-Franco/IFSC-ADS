
public class OrcKingdomFactory{
	public OrcArmy MakeOrcArmy() {
		return new OrcArmy();
	}
	
	public OrcCastle MakeOrcCastle() {
		return new OrcCastle();
	}
	
	public OrcKing MakeOrcKing() {
		return new OrcKing();
	}
}
