public class ElfCastle implements Castle{

  public String getDescription() {
    return "This is the Elf castle!";
  }
}
