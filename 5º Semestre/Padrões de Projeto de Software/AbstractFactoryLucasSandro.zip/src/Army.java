
public interface Army {
	String getDescription();
}
