
public class Kingdom {
	Army army;
	Castle castle;
	King king;
	
	public Kingdom(ElfKingdomFactory elfKingdomFactory) {
		army   = elfKingdomFactory.MakeElfArmy();
		castle = elfKingdomFactory.MakeElfCastle();
		king   = elfKingdomFactory.MakeElfKing();
	}

	public Kingdom(OrcKingdomFactory orcKingdomFactory) {
		army   = orcKingdomFactory.MakeOrcArmy();
		castle = orcKingdomFactory.MakeOrcCastle();
		king   = orcKingdomFactory.MakeOrcKing();
	}

	public void getDescription() {
		System.out.println("Army: "   + army.getDescription());
		System.out.println("Castle: " + castle.getDescription());
		System.out.println("King: "   + king.getDescription());
		
	}

}
