public class OrcArmy implements Army {

  public String getDescription() {
    return "This is the Orc Army!";
  }
}
