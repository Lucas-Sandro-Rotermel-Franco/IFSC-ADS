public class ElfKing implements King{

  public String getDescription() {
    return "This is the Elf king!";
  }
}
