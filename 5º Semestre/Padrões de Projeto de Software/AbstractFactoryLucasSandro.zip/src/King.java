
public interface King {
	String getDescription();
}
