import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JTextField;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Update implements ActionListener{
	
	JLabel label;
	JTextField textField;
	JButton button;
	DefaultListModel<String> listModel;
	String selectedValue;
	int index;
	
	public Update(String campo_a_ser_alterado, DefaultListModel<String> listModel, String selectedValue, int index) {
		
		this.listModel = listModel;
		this.selectedValue = selectedValue;
		this.index = index;
		
		JFrame frame = new JFrame("Update");
		frame.setVisible(true);
		frame.setSize(450, 80);
		frame.setLayout(new FlowLayout());
		
		label = new JLabel("Campo a ser alterado:");
		frame.add(label);
		
		textField = new JTextField(15);
		textField.setText(campo_a_ser_alterado);
		frame.add(textField);
		
		button = new JButton("Atualizar");
		button.addActionListener(this);
		frame.add(button);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		listModel.setElementAt(textField.getText(), index);
	}
}
