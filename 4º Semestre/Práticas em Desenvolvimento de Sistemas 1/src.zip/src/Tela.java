import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Tela implements ActionListener {
	
	JLabel label;
	JTextField textField1, textField2, textField3;
	JButton button;
	JCheckBox checkBox1, checkBox2, checkBox3;
	JRadioButton radioButton1, radioButton2;
	JPanel panel;
	ButtonGroup buttonGroup;
	JScrollPane scroll;
	JList<String> list = new JList<String>();
	DefaultListModel<String> listModel = new DefaultListModel<String>();
	
	public Tela() {
		JFrame frame = new JFrame("Cadastro");
		frame.setVisible(true);
		frame.setBounds(100, 100, 670, 260);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(null);
		
		label = new JLabel("Nome:");
		label.setBounds(10, 11, 46, 14);
		frame.add(label);
		textField1 = new JTextField(20);
		textField1.setBounds(48, 8, 210, 20);
		frame.add(textField1);
		
		label = new JLabel("Endere�o:");
		label.setBounds(10, 42, 59, 14);
		frame.add(label);
		textField2 = new JTextField(18);
		textField2.setBounds(70, 39, 188, 20);
		frame.add(textField2);
		
		label = new JLabel("Cidade:");
		label.setBounds(10, 74, 46, 14);
		frame.add(label);
		textField3 = new JTextField(19);
		textField3.setBounds(59, 71, 199, 20);
		frame.add(textField3);
		
		label = new JLabel("Sexo:");
		label.setBounds(10, 116, 37, 14);
		frame.add(label);
		
		radioButton1 = new JRadioButton("Masculino");
		radioButton1.setBounds(48, 112, 71, 23);
		radioButton1.setActionCommand("Masculino");
		radioButton1.addActionListener(this);
		
		radioButton2 = new JRadioButton("Feminino");
		radioButton2.setBounds(121, 112, 71, 23);
		radioButton2.setActionCommand("Feminino");
		radioButton2.addActionListener(this);
		
		panel = new JPanel();
		panel.add(radioButton1);
		panel.add(radioButton2);
		
		buttonGroup = new ButtonGroup();
		buttonGroup.add(radioButton1);
		buttonGroup.add(radioButton2);
		panel.setBounds(30, 107, 200, 23);
		frame.add(panel);
		
		label = new JLabel("Cursos:");
		label.setBounds(10, 153, 46, 14);
		frame.add(label);
		
		checkBox1 = new JCheckBox("Curso 1");
		checkBox1.setBounds(60, 149, 71, 23);
		checkBox2 = new JCheckBox("Curso 2");
		checkBox2.setBounds(129, 149, 71, 23);
		checkBox3 = new JCheckBox("Curso 3");
		checkBox3.setBounds(200, 149, 71, 23);
		
		frame.add(checkBox1);
		frame.add(checkBox2);
		frame.add(checkBox3);
		
		button = new JButton("Adicionar");
		button.addActionListener(this);
		button.setBounds(121, 187, 89, 23);
		frame.add(button);
		
		scroll = new JScrollPane(list);
		scroll.setPreferredSize(new java.awt.Dimension(350,180));
	    scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
	    scroll.setBounds(290, 10, 351, 161);
	    frame.add(scroll);
	    
		list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	
		button = new JButton("Editar");
		button.addActionListener(this);
		button.setBounds(375, 187, 89, 23);
		frame.add(button);	
		
		button = new JButton("Limpar");
		button.addActionListener(this);
		button.setBounds(488, 187, 89, 23);
		frame.add(button);	
	}
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			
			@Override
			public void run() {
				new Tela();
			}
		});
	}
	
	private String verificarSexo() {
		
		if(radioButton1.isSelected())
	        return radioButton1.getText();
		else if(radioButton2.isSelected())
			return radioButton2.getText();
		
		return "Sexo n�o informado";
	}
	
	private String validarTexto(String texto, String mensagemErro) {
		
		if(texto.trim().equals("")) {
			return mensagemErro;
		}
		
		return texto;
	}
	
	private String validarCheckBox(JCheckBox checkBox, String mensagem, String mensagemErro) {
		
		if(checkBox.isSelected()) {
			return mensagem;
		}
		
		return mensagemErro;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getActionCommand().equalsIgnoreCase("Adicionar")) {

			list.setModel(listModel);
			listModel.addElement(validarTexto(textField1.getText(), 
					"Nome n�o informado"));
			
			listModel.addElement(validarTexto(textField2.getText(), 
					"Endere�o n�o informado"));
			
			listModel.addElement(validarTexto(textField3.getText(), 
					"Cidade n�o informada"));
			
			listModel.addElement(verificarSexo());
			listModel.addElement(validarCheckBox(checkBox1, "Curso 1", "Curso 1 n�o selecionado"));
			listModel.addElement(validarCheckBox(checkBox2, "Curso 2", "Curso 2 n�o selecionado"));
			listModel.addElement(validarCheckBox(checkBox3, "Curso 3", "Curso 3 n�o selecionado"));
			listModel.addElement("======================================");
			
			textField1.setText("");
			textField2.setText("");
			textField3.setText("");
			buttonGroup.clearSelection();
			((JCheckBox) checkBox1).setSelected(false);
			((JCheckBox) checkBox2).setSelected(false);
			((JCheckBox) checkBox3).setSelected(false);
		} 
		else if (e.getActionCommand().equalsIgnoreCase("Editar")) {

			String selectedValue = list.getSelectedValue();
			int index = list.getSelectedIndex();

			new Update(selectedValue, listModel, selectedValue, index);
		}
		else if(e.getActionCommand().equalsIgnoreCase("Limpar")) {
			listModel.clear();
			list.setModel(listModel);
		}
	}	
}
