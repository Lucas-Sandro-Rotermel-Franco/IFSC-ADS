
insert into funcionario( nome, profissao, salario ) values ("Paulo","Engenheiro", 2000); 
insert into funcionario( nome, profissao, salario ) values ("Andre","Programador", 2000); 
insert into funcionario( nome, profissao, salario ) values ("Julia","Gerente", 2500); 
insert into funcionario( nome, profissao, salario ) values ("Pedro","Advogado", 2500); 


