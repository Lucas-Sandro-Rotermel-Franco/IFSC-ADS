
public class Main {

	public static void main(String[] args) {
		SistemaCampoMinado sistema = new SistemaCampoMinado();
		sistema.iniciarSistema();
	}

}
