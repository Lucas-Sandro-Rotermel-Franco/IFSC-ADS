package campominado;

public interface HistoricoDAO {

	//implementar
	
}