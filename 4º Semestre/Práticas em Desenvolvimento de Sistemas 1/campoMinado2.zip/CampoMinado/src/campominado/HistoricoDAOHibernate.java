package campominado;

public class HistoricoDAOHibernate implements HistoricoDAO {

	//implementar	

}
