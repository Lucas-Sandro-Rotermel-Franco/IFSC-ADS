package Default;

public class Cadastro
{
    String nome;
    String endereco;
    String cidade;
    String sexo;
    String curso;

    public Cadastro(String nome, String endereco, String cidade, String sexo, String curso)
    {
        this.nome = nome ;
        this.endereco = "\n" + endereco;
        this.cidade = "\n" + cidade + "\n";
        this.sexo = sexo;
        this.curso = curso;
    }

    public String getNome()
    {
        return nome;
    }

    public void setNome(String nome)
    {
        this.nome = nome;
    }

    public String getEndereco()
    {
        return endereco;
    }

    public void setEndereco(String endereco)
    {
        this.endereco = endereco;
    }

    public String getCidade()
    {
        return cidade;
    }

    public void setCidade(String cidade)
    {
        this.cidade = cidade;
    }

    public String getSexo()
    {
        return sexo;
    }

    public void setSexo(String sexo)
    {
        this.sexo = sexo;
    }

    public String getCurso()
    {
        return curso;
    }

    public void setCurso(String curso)
    {
        this.curso = curso;
    }

    public String toString()
    {
        return getNome() + getEndereco() + getCidade() + getSexo() + getCurso();
    }
}
