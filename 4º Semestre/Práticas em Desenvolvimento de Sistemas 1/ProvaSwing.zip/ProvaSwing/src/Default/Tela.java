package Default;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;

public class Tela implements ActionListener, ItemListener
{
	JTextField tfNome;
	JTextField tfEndereco;
	JTextField tfCidade;
	
	JButton btnAdicionar;
	JButton btnEditar;
	JButton btnLimpar;
	
	JCheckBox jcbCurso1;
	JCheckBox jcbCurso2;
	JCheckBox jcbCurso3;
	
	JLabel lbPrincipal;
	JLabel lbResposta;
	
	String valor = "";
	String texto = "";
	String genero = "";
	
	JPanel ladoDireito, textoladoDireito, botoesLadoDireito, camposCadastro, panel1, panel2,
			panelNome, panelEdereco, panelCidade, panelAdicionar, panelTexto;
	
	JRadioButton rdbMasculino;
	JRadioButton rdbFeminino;
	
	JTextArea taResult;
	JScrollPane spScrol;
	
	ButtonGroup btngGroup;
	
	Cadastro cadastro;
	
	public Tela ()
	{
		JFrame frame = new JFrame(":p");
		frame.setVisible(true);
		frame.setSize(900, 350);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);		
		
		panelNome = new JPanel(new FlowLayout(FlowLayout.LEFT));
		panelEdereco = new JPanel(new FlowLayout(FlowLayout.LEFT));
		panelCidade = new JPanel(new FlowLayout(FlowLayout.LEFT));
		panel1 = new JPanel(new FlowLayout(FlowLayout.LEFT));
		panel2 = new JPanel(new FlowLayout(FlowLayout.LEFT));
		panelAdicionar = new JPanel(new FlowLayout(FlowLayout.CENTER));
		camposCadastro = new JPanel(new GridLayout(6, 1));
		
		lbPrincipal = new JLabel("Nome: ");
		panelNome.add(lbPrincipal);
		
		tfNome = new JTextField(23);
		tfNome.addActionListener(this);
		tfNome.setActionCommand("");
		panelNome.add(tfNome);
		
		camposCadastro.add(panelNome, BorderLayout.WEST);
		
		lbPrincipal = new JLabel("Endere�o: ");
		panelEdereco.add(lbPrincipal);
		
		tfEndereco = new JTextField(21);
		tfEndereco.addActionListener(this);
		tfEndereco.setActionCommand("");
		panelEdereco.add(tfEndereco);

		camposCadastro.add(panelEdereco, BorderLayout.WEST);
		
		lbPrincipal = new JLabel("Cidade: ");
		panelCidade.add(lbPrincipal);
		
		tfCidade = new JTextField(23);
		tfCidade.addActionListener(this);
		tfCidade.setActionCommand("");
		panelCidade.add(tfCidade);
		
		camposCadastro.add(panelCidade, BorderLayout.WEST);
		
		lbPrincipal = new JLabel("Sexo:");
		panel1.add(lbPrincipal);
		
		rdbMasculino = new JRadioButton("Masculino");
		rdbMasculino.setActionCommand("Masculino");
		rdbMasculino.addActionListener(this);
		panel1.add(rdbMasculino);
		
		rdbFeminino = new JRadioButton("Feminino");
		rdbFeminino.setActionCommand("Feminino");
		rdbFeminino.addActionListener(this);
		panel1.add(rdbFeminino);
		
		btngGroup = new ButtonGroup();
		btngGroup.add(rdbMasculino);
		btngGroup.add(rdbFeminino);
		
		camposCadastro.add(panel1);
		
		lbPrincipal = new JLabel("Cursos:");
		panel2.add(lbPrincipal);
		
		jcbCurso1 = new JCheckBox("Curso 1");
		jcbCurso1.addItemListener(this);
		panel2.add(jcbCurso1);
		
		jcbCurso2 = new JCheckBox("Curso 2");
		jcbCurso2.addItemListener(this);
		panel2.add(jcbCurso2);
		
		jcbCurso3 = new JCheckBox("Curso 3");
		jcbCurso3.addItemListener(this);
		panel2.add(jcbCurso3);
		
		camposCadastro.add(panel2);

		btnAdicionar = new JButton("Adicionar");
		btnAdicionar.addActionListener(this);
		panelAdicionar.add(btnAdicionar);
		
		camposCadastro.add(panelAdicionar);
		
		frame.getContentPane().add(camposCadastro, BorderLayout.WEST);
		ladoDireito = new JPanel();
		GridBagLayout gbl_ladoDireito = new GridBagLayout();
		gbl_ladoDireito.columnWidths = new int[]{633, 0};
		gbl_ladoDireito.rowHeights = new int[] {290, 50, 0};
		gbl_ladoDireito.columnWeights = new double[]{0.0, Double.MIN_VALUE};
		gbl_ladoDireito.rowWeights = new double[]{0.0, 0.0};
		ladoDireito.setLayout(gbl_ladoDireito);
		
		textoladoDireito = new JPanel(new GridLayout(1,0));
		
		taResult = new JTextArea();
		spScrol = new JScrollPane(taResult);
		textoladoDireito.add(spScrol, BorderLayout.CENTER);
		GridBagConstraints gbc_textoladoDireito = new GridBagConstraints();
		gbc_textoladoDireito.fill = GridBagConstraints.BOTH;
		gbc_textoladoDireito.insets = new Insets(0, 0, 5, 0);
		gbc_textoladoDireito.gridx = 0;
		gbc_textoladoDireito.gridy = 0;
		ladoDireito.add(textoladoDireito, gbc_textoladoDireito);
		
		frame.getContentPane().add(ladoDireito, BorderLayout.CENTER);
		botoesLadoDireito = new JPanel(new FlowLayout(FlowLayout.CENTER));
		
		btnEditar = new JButton("Editar");
		btnEditar.addActionListener(this);
		botoesLadoDireito.add(btnEditar, BorderLayout.EAST);
		
		btnLimpar = new JButton("Limpar");
		btnLimpar.addActionListener(this);
		botoesLadoDireito.add(btnLimpar, BorderLayout.EAST);
		
		GridBagConstraints gbc_botoesLadoDireito = new GridBagConstraints();
		gbc_botoesLadoDireito.fill = GridBagConstraints.BOTH;
		gbc_botoesLadoDireito.gridx = 0;
		gbc_botoesLadoDireito.gridy = 1;
		ladoDireito.add(botoesLadoDireito, gbc_botoesLadoDireito);
	}

	@Override
	public void actionPerformed(ActionEvent e)
	{
		String auxGenero = e.getActionCommand().toString();

		if (auxGenero.equals("Masculino") || auxGenero.equals("Feminino"))
			genero = auxGenero;

		if (e.getActionCommand().equalsIgnoreCase("Adicionar"))
		{
			cadastro = new Cadastro(tfNome.getText(), tfEndereco.getText(), tfCidade.getText(), genero, texto);
			valor += cadastro + "\n--------------------------\n";
			
			taResult.setText(valor);
			taResult.setEnabled(false);
			taResult.setDisabledTextColor(Color.BLACK);
			
			tfNome.setText("");
			tfEndereco.setText("");
			tfCidade.setText("");
			btngGroup.clearSelection();
			
			jcbCurso1.setSelected(false);
			jcbCurso2.setSelected(false);
			jcbCurso3.setSelected(false);
		}

		if (e.getActionCommand().equalsIgnoreCase("Limpar"))
		{
			taResult.setText("");
			taResult.setEnabled(false);
			taResult.setDisabledTextColor(Color.black);
		}
		
		if (e.getActionCommand().equalsIgnoreCase("Editar"))
		{
			taResult.setEnabled(true);
			valor = taResult.getText();
			taResult.setText(valor);
		}
	}

	@Override
	public void itemStateChanged(ItemEvent e)
	{
		String value="";
		
		if (jcbCurso1.isSelected())
			value += "\nCurso 1";
		else
			value += "";
		
		if (jcbCurso2.isSelected())
			value += "\nCurso 2";
		else
			value += "";
		
		if (jcbCurso3.isSelected())
			value += "\nCurso 3";
		else
			value += "";
		
		texto = value;
	}
}