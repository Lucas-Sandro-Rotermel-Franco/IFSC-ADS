public class Pessoa {
	String nome;
	String endereco;
	String cidade;
	String sexo;
	String cursos;

	public Pessoa(String nome, String endereco, String cidade, String sexo, String cursos) {
		super();
		this.nome = nome;
		this.endereco = endereco;
		this.cidade = cidade;
		this.sexo = sexo;
		this.cursos = cursos;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public String getCursos() {
		return cursos;
	}

	public void setCursos(String cursos) {
		this.cursos = cursos;
	}

	public String toString() {
		return getNome() + "\n" + getEndereco() + "\n" + getCidade() + "\n" + getSexo() + getCursos();
	}

}
