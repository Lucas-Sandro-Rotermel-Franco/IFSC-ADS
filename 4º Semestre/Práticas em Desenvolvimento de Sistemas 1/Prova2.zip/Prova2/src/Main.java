import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class Main implements ActionListener, ItemListener {
	JTextField nome, endereco, cidade;
	JButton adicionar, editar, limpar;
	JLabel label, resposta;
	JPanel ladoEsquerdo, camposCadastro, textoladoDireito, botoesLadoDireito, ladoDireito, sexo, curso, panelNome,
			panelAdicionar, panelEndereco, panelCidade;
	JRadioButton masculino, feminino;
	JCheckBox curso1, curso2, curso3;
	JTextArea result;
	JScrollPane scrolPanel;
	String valores = "";
	Pessoa pessoa;
	String str = "";
	String sexoPessoa = "";
	ButtonGroup group = new ButtonGroup();

	public Main() {
		JFrame frame = new JFrame("Cadastro");
		frame.setVisible(true);
		frame.setSize(800, 325);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		ladoEsquerdo = new JPanel(new FlowLayout(FlowLayout.LEFT));
		camposCadastro = new JPanel(new GridLayout(10, 2, 5, 5));

		panelNome = new JPanel(new FlowLayout(FlowLayout.LEFT));
		label = new JLabel("Nome:");
		panelNome.add(label);

		nome = new JTextField(20);
		nome.addActionListener(this);
		nome.setActionCommand("");
		panelNome.add(nome);

		camposCadastro.add(panelNome);

		panelEndereco = new JPanel(new FlowLayout(FlowLayout.LEFT));

		label = new JLabel("Endere�o:");
		panelEndereco.add(label);

		endereco = new JTextField(18);
		endereco.addActionListener(this);
		endereco.setActionCommand("");
		panelEndereco.add(endereco);

		camposCadastro.add(panelEndereco);

		panelCidade = new JPanel(new FlowLayout(FlowLayout.LEFT));

		label = new JLabel("Cidade:");
		panelCidade.add(label);

		cidade = new JTextField(20);
		cidade.addActionListener(this);
		cidade.setActionCommand("");
		panelCidade.add(cidade);

		camposCadastro.add(panelCidade);

		sexo = new JPanel(new FlowLayout(FlowLayout.LEFT));
		label = new JLabel("Sexo:");
		sexo.add(label);

		masculino = new JRadioButton("Masculino");
		masculino.setActionCommand("Masculino");
		masculino.addActionListener(this);
		sexo.add(masculino);

		feminino = new JRadioButton("Feminino");
		feminino.setActionCommand("Feminino");
		feminino.addActionListener(this);
		sexo.add(feminino);

		camposCadastro.add(sexo);

		group.add(masculino);
		group.add(feminino);

		curso = new JPanel(new FlowLayout(FlowLayout.LEFT));
		label = new JLabel("Cursos:");
		curso.add(label);

		curso1 = new JCheckBox("Curso 1");
		curso1.addItemListener(this);
		curso.add(curso1);

		curso2 = new JCheckBox("Curso 2");
		curso2.addItemListener(this);
		curso.add(curso2);

		curso3 = new JCheckBox("Curso 3");
		curso3.addItemListener(this);
		curso.add(curso3);

		camposCadastro.add(curso);

		panelAdicionar = new JPanel(new FlowLayout(FlowLayout.CENTER));
		adicionar = new JButton("Adicionar");
		adicionar.addActionListener(this);
		panelAdicionar.add(adicionar);

		camposCadastro.add(panelAdicionar);

		ladoEsquerdo.add(camposCadastro);
		frame.add(ladoEsquerdo, BorderLayout.WEST);

		ladoDireito = new JPanel(new FlowLayout(FlowLayout.CENTER));
		textoladoDireito = new JPanel(new GridLayout(1, 0));
		botoesLadoDireito = new JPanel(new GridLayout(0, 2));

		result = new JTextArea(valores);
		result.setEnabled(false);
		result.setDisabledTextColor(Color.BLACK);
		scrolPanel = new JScrollPane(result);
		textoladoDireito.add(scrolPanel);
		textoladoDireito.setBackground(Color.red);
		frame.add(textoladoDireito, BorderLayout.CENTER);

		editar = new JButton("Editar");
		editar.addActionListener(this);
		botoesLadoDireito.add(editar);

		limpar = new JButton("Limpar");
		limpar.addActionListener(this);
		botoesLadoDireito.add(limpar);
		botoesLadoDireito.setBackground(Color.red);

		ladoDireito.add(botoesLadoDireito, BorderLayout.CENTER);
		frame.add(ladoDireito, BorderLayout.SOUTH);

	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				new Main();
			}
		});
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		String aux = e.getActionCommand().toString();

		if (aux.equals("Masculino") || aux.equals("Feminino")) {
			sexoPessoa = aux;
		}

		if (e.getActionCommand().equalsIgnoreCase("Adicionar")) {
			pessoa = new Pessoa(nome.getText(), endereco.getText(), cidade.getText(), sexoPessoa, str);
			valores += "\n" + pessoa + "\n==========================";
			result.setText(valores);
			result.setEnabled(false);
			result.setDisabledTextColor(Color.BLACK);
			nome.setText("");
			endereco.setText("");
			cidade.setText("");
			curso1.setSelected(false);
			curso2.setSelected(false);
			curso3.setSelected(false);
			group.clearSelection();
		}

		if (e.getActionCommand().equalsIgnoreCase("Editar")) {
			result.setEnabled(true);
			valores = result.getText();
			result.setText(valores);
		}

		if (e.getActionCommand().equalsIgnoreCase("Limpar")) {
			result.setText("");
			result.setEnabled(false);
			result.setDisabledTextColor(Color.BLACK);
		}

	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		String valor = "";
		valor += curso1.isSelected() ? "\nCurso 1" : "";
		valor += curso2.isSelected() ? "\nCurso 2" : "";
		valor += curso3.isSelected() ? "\nCurso 3" : "";

		str = valor;
	}

}
