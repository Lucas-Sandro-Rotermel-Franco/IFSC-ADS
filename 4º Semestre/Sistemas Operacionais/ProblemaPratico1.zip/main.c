#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdio.h>

int main (void) {
 do {
    int numero, fatorial;
    printf("Informe um numero:");
    scanf("%d", &numero) ;
    pid_t filho_pid = fork();

    if (filho_pid == 0) {
      int numeroOriginal = numero;
      for(fatorial = 1; numero > 1; numero--)
      {      
        fatorial = fatorial * numero;
      }

      printf("\nO fatorial do numero %d eh: %d\n", numeroOriginal, fatorial);
    }
 } while(0 == 0);
 return 0;
}
