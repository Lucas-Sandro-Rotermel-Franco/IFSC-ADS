#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdio.h>

int main (void) {
 char* comando[] = {"df", NULL};

 if(fork() == 0) {
   printf("Arquivos no diretorio\n");
   execvp(comando[0], comando);
   printf("Processo filho\n");
 } else {
   printf("Processo pai\n");
 }

 printf("Fim\n");
 return 0;
}
