$(document).ready(function() {
	alert ('testando o Jquery!');
});